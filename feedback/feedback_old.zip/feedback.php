<?
if(isset($_POST['feedback_feedbacks']))
{
	feedback_feedbacks();	
	die();
}
if(isset($_POST['feedback_send']))
{
	feedback_send();	
	die();
}
function feedback_send()
{
	require_once('../phpmailer/PHPMailer/class.phpmailer.php');
	include_once "../conf/config_filtros.php";
	include_once "../php/funciones.php";
	include_once "../conf/config.php";
	include_once "../conf/config_".curPageName().".php";
	include_once "../../soporte/DB.php";
	include_once "../../soporte/funcionesgenerales.php";
	
	$tipo_error        = 0;
	$correos           = array();
	$colas             = array();
	$contador_correos  = 0;
	$fechas_historicas = '';	
	$tarea             = $_GET['tarea'];
	$contador          = 0;
	$usuario           = $_GET['usuario'];
	$To_Correcto       = false;
	$TO                = '';
	$COPIAS            = '';
	$FROM              = '';
	$FROM_NAME         = '';
	$From_Correcto     = false;
	$new_mail_A        = '';
	$new_mail_B        = ''; 
	$correos_extras    = $_POST['correos_extras'];
	
	DBConectar($GLOBALS["cfg_DataBase"]);
	if($correos_extras!='')
	{
		$array_correos_extras = explode("|", $correos_extras);
		foreach($array_correos_extras as $array_correo_extra)
		{
			if($array_correo_extra!='')
			{
				$new_mail_A  = $new_mail_A.",'".$array_correo_extra."'";				
			}
		}
		$new_mail_A = trim($new_mail_A,",");
		$mail=DBSelect(utf8_decode("SELECT Mail FROM (SELECT Mail,sAMAccountName ,Name  FROM OpenQuery(ADSI, 'SELECT Mail,sAMAccountName,Name FROM ''LDAP://DC=sp-berner,DC=local'' WHERE objectCategory=''user'' ')) Consulta WHERE Consulta.Name IN   (".$new_mail_A.")"));
		for(;DBNext($mail);)
		{	
			$DIRECCION   = utf8_encode(DBCampo($mail,"Mail"));
			if($DIRECCION !="")
			{
				$correos[$contador_correos] = $DIRECCION;
				$contador_correos           = $contador_correos + 1;
				$To_Correcto=true;	
			}
		}		
	}
	
	
	$s=DBSelect(utf8_decode("EXECUTE [INICIAR_MANDAR_FEEDBACK] ".$tarea.", '".$usuario."', 0"));
	for(;DBNext($s);)
	{	
		$contador  = $contador+1;
		$ACTOR     = (DBCampo($s,"ACTOR"));
		$DIRECCION = utf8_encode(DBCampo($s,"MAIL"));					
		$USUARIO   = utf8_encode(DBCampo($s,"USUARIO"));
		$NOMBRE    = utf8_encode(DBCampo($s,"NOMBRE"));
		$titulo    = utf8_encode(DBCampo($s,"titulo"));
		if ($ACTOR==1) 
		{
			if($DIRECCION !="")
			{
				$correos[$contador_correos] = $DIRECCION;
				$contador_correos           = $contador_correos + 1;
				$To_Correcto=true;	
			}
		}
		if ($ACTOR!=1) 
		{
			if($DIRECCION !="")
			{
				if ($USUARIO!=$usuario)
				{
					$correos[$contador_correos] = $DIRECCION;
					$contador_correos           = $contador_correos + 1;
				}
				else
				{
					$FROM         = $DIRECCION;
					$FROM_NAME    = $NOMBRE ;
					$From_Correcto=true;						
				}
			}
		}				
	}

	
	if ($To_Correcto==true && $From_Correcto==true)
	{				
		$subject = 'Feedback de fecha para la tarea '.$tarea.' - ('.$titulo.')';		
  	    $message = $_POST['feedback_message'];
		try
		{		 
			// 08/02/2017 T#17145 - WEB TAREAS. Estructuras: modificar interlocutores de envío mensajes de feed back
			$encontrado_ana = false;
			$encontrado_cristobal = false;
			
			ini_set('SMTP', "mail.sp-berner.com");
			ini_set('smtp_port', "25");
			ini_set('sendmail_from', $FROM);
			$email = new PHPMailer();
			$email->IsHTML(true); 
			$email->From      = utf8_decode($FROM);
			$email->FromName  = utf8_decode($FROM_NAME) ;
			$email->Subject   = utf8_decode($subject);
			$email->Body      = utf8_decode($message) ;
			$email->AddAddress( $FROM );			
			foreach ($correos as $correo) 
			{
				$email->AddAddress( $correo );
				
				if(strtolower($correo)=='anacristobalxercavins@sp-berner.com'){
					$encontrado_ana = true;
				}
					
				if(strtolower($correo)=='cristobal.seijo@sp-berner.com'){
					$encontrado_cristobal = true;
				}
			}						
			
			// 08/02/2017 T#17145 - WEB TAREAS. Estructuras: modificar interlocutores de envío mensajes de feed back
			if(curPageName() == 'GESTIONPROYECTOSESTRUCTURAS'){
				if(!$encontrado_cristobal){
					$email->AddBCC( 'cristobal.seijo@sp-berner.com' );
				}
				if(!$encontrado_ana){
					$email->AddBCC( 'AnaCristobalXercavins@sp-berner.com' );
				}
			}
			$res = $email->Send();
			
			//$res = 0;
			
		}
		catch(Exception $e)
		{
			$tipo_error = -1;
			$txt_error  = 'Cuando se envia un feedback se manda un correo a todos los participantes anunciandolo. Se ha producido un error:';
			$colas[0]   = array("mensaje"=>$txt_error.$e);
		}
	}
	if($tipo_error ==0)
	{
		if ($To_Correcto==false || $From_Correcto==false)
		{
			$tipo_error = -1;
			$txt_error  = 'Cuando se envia un feedback se manda un correo a todos los participantes anunciandolo. El correo no se ha podido enviar. Alguno de los destinatarios no tiene correo o no es correcto.';
			$colas[0]   =array("mensaje"=>$txt_error);	
		}
		else
		{
			if($res==1)
			{								
				$tipo_error = 1;
				$txt_error  = 'Correo <b>correcto</b> enviado a todos los participantes.';
				$colas[0]   = array("mensaje"=>$txt_error);
				foreach ($correos as $correo) 
				{
					$q  = DBSelect(utf8_decode("INSERT INTO [feedback] ([Tarea],[fecha],[usuario],[destino],[feedback])  VALUES (".$tarea.",GETDATE() ,'".$usuario."','".$correo."','".str_replace("'", "''", ($message))."')"));
				}
			}
			else
			{
				$tipo_error = -1;
				$txt_error  = 'Cuando se envia un feedback se manda un correo a todos los participantes anunciandolo. El correo no se ha podido enviar. Intentelo de nuevo';
				$colas[0]   =array("mensaje"=>$txt_error);
			}

		}
	}
	DBFree($s);				
	DBClose();
	$json_arr = array('tipo' => $tipo_error,'tarea' => $tarea, 'data'=>$colas);
	$php_json = json_encode($json_arr);
	
	echo $php_json;

}

function feedback_feedbacks()
{	
	include_once "../conf/config_filtros.php";
	include_once "../php/funciones.php";
	include_once "../conf/config.php";
	include_once "../conf/config_".curPageName().".php";
	include_once "../../soporte/DB.php";
	include_once "../../soporte/funcionesgenerales.php";

	$fechas_historicas = '';	
	$tarea             = $_GET['tarea'];

	DBConectar($GLOBALS["cfg_DataBase"]);
	$q=DBSelect(utf8_decode("SELECT distinct convert(varchar(20),Fecha,105)+' '+convert(varchar(20),Fecha,108) as fecha  FROM [feedback] where [Tarea] = ".$tarea." "));
	for(;DBNext($q);)
	{
		$fecha=DBCampo($q,"fecha");
		$fechas_historicas =  $fechas_historicas.'<div class="feedback_lista">'.utf8_encode($fecha).'</div>';
	}		
	if($fechas_historicas!='')
	{		
		echo '<div>Envios anteriores:</div>';
		echo '<div class="feedback_fechas">';
		echo $fechas_historicas;
		echo '</div>';
		
	}
	$contador = 0;
	$usuario  = $_GET['usuario'];
	$query="
			SELECT 
				CAST([Título] as varchar(250)) as titulo
				,CONVERT(varchar(250),[Fecha objetivo],106) as fecha
				,[Categoría] as categoria
      			,[Tipo]	as tipo
			FROM [Tareas y Proyectos] where Id = ".$tarea;
	$typ=DBSelect(utf8_decode($query));
	$typ_titulo=DBCampo($typ,"titulo");
	$typ_fecha =DBCampo($typ,"fecha");
	$typ_tipo =DBCampo($typ,"tipo");
	$typ_categoria =DBCampo($typ,"categoria");
	
	echo '<div class="feedback_bloque">Destinatarios del Feedback actual:</div>';	
	echo '<div class="feedback_destinatarios">';
	$s=DBSelect(utf8_decode("EXECUTE [INICIAR_MANDAR_FEEDBACK] ".$tarea.", '".$usuario."', 0"));
	// 08/02/2017 T#17145 - WEB TAREAS. Estructuras: modificar interlocutores de envío mensajes de feed back
	$encontrado_ana = false;
	$encontrado_cristobal = false;
	for(;DBNext($s);)
	{	
		$contador  = $contador+1;
		$ACTOR     = (DBCampo($s,"ACTOR"));
		$DIRECCION = utf8_encode(DBCampo($s,"MAIL"));
		$USUARIO   = utf8_encode(DBCampo($s,"USUARIO"));
		if ($USUARIO!=$usuario)
		{
			if($DIRECCION !="")
			{		
				echo '<div>'.$DIRECCION.'</div>';
				
				if(strtolower($DIRECCION)=='anacristobalxercavins@sp-berner.com'){
					$encontrado_ana = true;
				}
			
				if(strtolower($DIRECCION)=='cristobal.seijo@sp-berner.com'){
					$encontrado_cristobal = true;
				}
			}
			
		}				
		
	}
	// 08/02/2017 T#17145 - WEB TAREAS. Estructuras: modificar interlocutores de envío mensajes de feed back
	if(curPageName() == 'GESTIONPROYECTOSESTRUCTURAS'){
		if(!$encontrado_cristobal){
			echo '<div>CC: cristobal.seijo@sp-berner.com</div>';
		}
		if(!$encontrado_ana){
			echo '<div>CC: AnaCristobalXercavins@sp-berner.com</div>';
		}
	}
	
	echo '</div>';
	echo '<div class="feedback_bloque">Más Destinatarios:<input id="autocompletemascorreo" name="autocompletemascorreo"></input><img class="feedback_mas_imagen" id="feedback_mas_imagen" src="feedback/imagen/more.png" onclick="feedback_more('.$tarea.');"></div>';
	echo '<div class="feedback_destinatarios" id="feedback_destinatarios_mas"></div>';	
	echo '<div class="feedback_bloque">Texto para enviar:</div>';
	echo '<div><div id="feedback_textarea" contenteditable="true" style="height: 110px;overflow-y: scroll;border: solid 1px;background-color: rgba(255, 255, 255, 0.85);width: 100%;">
			Buenos días: <br><br>
			
			A continuación se detallan los datos de la tarea <b>'.$tarea.' '.utf8_encode($typ_titulo).'</b><br>
			Fecha objetivo: '.$typ_fecha.'<br>
			Tipo: ' . utf8_encode($typ_tipo) . '<br>
			Categoría: ' . utf8_encode($typ_categoria) . '<br>
			Si por urgencia de servicio, necesitaras el trabajo con anterioridad, lo comentamos primero juntos y consensuamos fecha.<br>
			Gracias, saludos
			</div></div>';
	echo '<div id="feedback_confirmar" class="feedback_confirmar"><img class="feedback_confirmar_imagen" id="feedback_confirmar_imagen" src="imagenes/feedback_confirmar.png" onclick="feedback_send('.$tarea.');"></div>';
	DBFree($q);				
	DBClose();
}

/*
 * 

 * 
 */
?>















