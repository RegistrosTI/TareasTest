/** @author martin fox */
$.paramquery.pqGrid.regional['nl'] = {
    strLoading: "Laden van gegevens",
    strAdd: "toevoegen",
    strEdit: "opstellen",
    strDelete: "uitgeven",
    strSearch: "Zoeken",
    strNothingFound: "niets gevonden",
    strSelectedmatches: "Gekozen {0} van {1} partuur(en)",
    strPrevResult: "Vorige Resultaat",
    strNextResult: "Volgende Resultaat",
    strNoRows: "Geen rijen weer te geven"
};
$.paramquery.pqPager.regional['nl'] = {
    strPage: "Pagina {0} van {1}",
    strFirstPage: "Eerste pagina",
    strPrevPage: "Vorige pagina",
    strNextPage: "Volgende pagina",
    strLastPage: "Laatste pagina",
    strRefresh: "Verfrissen",
    strRpp: "Notulen per pagina: {0}",
    strDisplay: "Weergeven {0} t&m {1} van {2} artikelen."
};